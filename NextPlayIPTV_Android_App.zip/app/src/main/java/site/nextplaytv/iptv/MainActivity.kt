package site.nextplaytv.iptv

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView

class MainActivity : Activity() {

    private var webView: WebView? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var rootContainer: FrameLayout? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } catch (_: Throwable) {}

        val container = FrameLayout(this)
        container.setBackgroundColor(Color.parseColor("#030712"))
        rootContainer = container

        try {
            val wv = WebView(this)
            wv.setBackgroundColor(Color.parseColor("#030712"))
            wv.isFocusable = true
            wv.isFocusableInTouchMode = true
            wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)

            val s = wv.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.databaseEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.allowFileAccess = true
            s.allowContentAccess = true
            try {
                @Suppress("DEPRECATION")
                s.allowUniversalAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                s.allowFileAccessFromFileURLs = true
            } catch (_: Throwable) {}
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }
            s.useWideViewPort = true
            s.loadWithOverviewMode = true
            s.cacheMode = WebSettings.LOAD_DEFAULT
            s.userAgentString = "NEXTPLAY-IPTV-AndroidTV/2.0 (Mobile; Android TV) AppleWebKit/537.36 Chrome/124.0.0.0"

            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    return false
                }
            }

            wv.webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    webView?.visibility = View.GONE
                    rootContainer?.addView(
                        view,
                        FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    )
                    safeHideSystemUI()
                }

                override fun onHideCustomView() {
                    customView?.let { rootContainer?.removeView(it) }
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    webView?.visibility = View.VISIBLE
                    safeHideSystemUI()
                }
            }

            webView = wv
            container.addView(
                wv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            setContentView(container)
            safeHideSystemUI()
            wv.loadUrl("file:///android_asset/www/index.html")
        } catch (err: Throwable) {
            val tv = TextView(this)
            tv.setTextColor(Color.WHITE)
            tv.setBackgroundColor(Color.parseColor("#030712"))
            tv.setPadding(40, 80, 40, 40)
            tv.text = "NEXT PLAY IPTV — Please update Android System WebView from Play Store.

Error: " + (err.message ?: err.toString())
            container.addView(tv)
            setContentView(container)
        }
    }

    private fun safeHideSystemUI() {
        try {
            window.decorView.post {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        window.setDecorFitsSystemWindows(false)
                        window.insetsController?.let { c ->
                            c.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                            c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        window.decorView.systemUiVisibility = (
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_FULLSCREEN
                        )
                    }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) safeHideSystemUI()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (customView != null) {
                webView?.webChromeClient?.onHideCustomView()
                return true
            }
            webView?.evaluateJavascript("window.__npAndroidBack && window.__npAndroidBack()", null)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onDestroy() {
        try { webView?.destroy() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
