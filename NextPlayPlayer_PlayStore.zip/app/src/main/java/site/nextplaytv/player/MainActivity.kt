package site.nextplaytv.player

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class MainActivity : Activity() {

    private var webView: WebView? = null
    private var rootContainer: FrameLayout? = null
    private var playerOverlay: FrameLayout? = null
    private var playerView: PlayerView? = null
    private var exoPlayer: ExoPlayer? = null
    private var titleBanner: TextView? = null
    private var resizeBtn: Button? = null
    private var resizeModeIdx = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE } catch (_: Throwable) {}
        try { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) } catch (_: Throwable) {}

        val container = FrameLayout(this)
        container.setBackgroundColor(Color.parseColor("#030712"))
        rootContainer = container

        try {
            val wv = WebView(this)
            wv.setBackgroundColor(Color.parseColor("#030712"))
            wv.isFocusable = true
            wv.isFocusableInTouchMode = true
            wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)

            val s = wv.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.databaseEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.allowFileAccess = true
            s.allowContentAccess = true
            try {
                @Suppress("DEPRECATION")
                s.allowUniversalAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                s.allowFileAccessFromFileURLs = true
            } catch (_: Throwable) {}
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }
            s.useWideViewPort = true
            s.loadWithOverviewMode = true
            s.cacheMode = WebSettings.LOAD_DEFAULT
            s.userAgentString = "NEXTPLAY-Player/2.0 (Android; Android TV) AppleWebKit/537.36 Chrome/126.0.0.0"

            wv.addJavascriptInterface(NativeBridge(), "NextPlayNative")
            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
            }
            wv.webChromeClient = WebChromeClient()

            webView = wv
            container.addView(wv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))

            buildNativePlayerOverlay(container)
            setContentView(container)
            safeHideSystemUI()
            wv.loadUrl("file:///android_asset/www/index.html")
        } catch (err: Throwable) {
            val tv = TextView(this)
            tv.setTextColor(Color.WHITE)
            tv.setBackgroundColor(Color.parseColor("#030712"))
            tv.setPadding(40, 80, 40, 40)
            tv.text = "NEXT PLAY Player Error: " + (err.message ?: err.toString())
            container.addView(tv)
            setContentView(container)
        }
    }

    private fun buildNativePlayerOverlay(container: FrameLayout) {
        val ov = FrameLayout(this)
        ov.setBackgroundColor(Color.BLACK)
        ov.visibility = View.GONE

        val pv = PlayerView(this)
        pv.useController = true
        pv.controllerAutoShow = true
        pv.controllerShowTimeoutMs = 4000
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        pv.setBackgroundColor(Color.BLACK)
        ov.addView(pv, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(24, 16, 24, 16)
        topBar.setBackgroundColor(Color.parseColor("#99030712"))

        val backBtn = Button(this)
        backBtn.text = "← Back"
        backBtn.setTextColor(Color.parseColor("#040712"))
        backBtn.setBackgroundColor(Color.parseColor("#FDE047"))
        backBtn.setOnClickListener { closeNativePlayer() }
        topBar.addView(backBtn)

        val titleTv = TextView(this)
        titleTv.setTextColor(Color.WHITE)
        titleTv.textSize = 15f
        titleTv.setPadding(24, 0, 24, 0)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        topBar.addView(titleTv, lp)

        val rBtn = Button(this)
        rBtn.text = "⛶ Fit"
        rBtn.setTextColor(Color.parseColor("#FDE047"))
        rBtn.setBackgroundColor(Color.parseColor("#CC0F172A"))
        rBtn.setOnClickListener {
            resizeModeIdx = (resizeModeIdx + 1) % 3
            val modes = intArrayOf(
                AspectRatioFrameLayout.RESIZE_MODE_FIT,
                AspectRatioFrameLayout.RESIZE_MODE_FILL,
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            )
            val labels = arrayOf("⛶ Fit", "⛶ Stretch", "⛶ Zoom")
            pv.resizeMode = modes[resizeModeIdx]
            rBtn.text = labels[resizeModeIdx]
        }
        topBar.addView(rBtn)

        ov.addView(topBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ))

        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = vis
        })

        playerOverlay = ov
        playerView = pv
        titleBanner = titleTv
        resizeBtn = rBtn
        container.addView(ov, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
    }

    private fun startNativeExoPlayer(url: String, title: String) {
        runOnUiThread {
            try {
                releaseExoPlayer()
                val httpFactory = DefaultHttpDataSource.Factory()
                    .setUserAgent("VLC/3.0.20 LibVLC/3.0.20")
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(8000)
                    .setReadTimeoutMs(12000)

                // Ultra-fast 1-second startup buffer profile (zero long waits, smooth playback!)
                val loadControl = DefaultLoadControl.Builder()
                    .setBufferDurationsMs(
                        6000,   // minBufferMs
                        30000,  // maxBufferMs
                        700,    // bufferForPlaybackMs (starts in <1 sec!)
                        1500    // bufferForPlaybackAfterRebufferMs
                    )
                    .build()

                val player = ExoPlayer.Builder(this)
                    .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
                    .setLoadControl(loadControl)
                    .build()

                player.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        titleBanner?.text = "$title  (Reconnecting…)"
                        player.prepare()
                        player.playWhenReady = true
                    }
                })

                val mediaItem = MediaItem.fromUri(Uri.parse(url))
                player.setMediaItem(mediaItem)
                player.prepare()
                player.playWhenReady = true

                exoPlayer = player
                playerView?.player = player
                titleBanner?.text = title
                playerOverlay?.visibility = View.VISIBLE
                safeHideSystemUI()
            } catch (e: Throwable) {
                titleBanner?.text = "Stream Error: " + (e.message ?: "")
            }
        }
    }

    private fun releaseExoPlayer() {
        try {
            playerView?.player = null
            exoPlayer?.stop()
            exoPlayer?.release()
            exoPlayer = null
        } catch (_: Throwable) {}
    }

    private fun closeNativePlayer() {
        runOnUiThread {
            releaseExoPlayer()
            playerOverlay?.visibility = View.GONE
            safeHideSystemUI()
        }
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun playStream(url: String, title: String, isLive: Boolean) {
            startNativeExoPlayer(url, title)
        }

        @JavascriptInterface
        fun stopStream() {
            closeNativePlayer()
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread {
                releaseExoPlayer()
                finishAffinity()
            }
        }
    }

    private fun safeHideSystemUI() {
        try {
            window.decorView.post {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        window.setDecorFitsSystemWindows(false)
                        window.insetsController?.let { c ->
                            c.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                            c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        window.decorView.systemUiVisibility = (
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_FULLSCREEN
                        )
                    }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) safeHideSystemUI()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (playerOverlay?.visibility == View.VISIBLE) {
                closeNativePlayer()
                return true
            }
            webView?.evaluateJavascript("window.__npAndroidBack && window.__npAndroidBack()", null)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onPause() {
        super.onPause()
        try { exoPlayer?.pause() } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        releaseExoPlayer()
        try { webView?.destroy() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
