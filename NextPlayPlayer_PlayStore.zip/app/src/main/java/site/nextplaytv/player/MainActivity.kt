package site.nextplaytv.player

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.UiModeManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * NEXT PLAY Player
 *  - WebView = UI (login / home / categories / channel list)
 *  - ONE native ExoPlayer (hardware decoding) that is re-used for every channel:
 *      preview mode    -> small video inside the right-hand pane of the Live TV screen
 *      fullscreen mode -> same player expanded to the whole screen (OK on remote / tap)
 */
class MainActivity : Activity() {

    private var webView: WebView? = null
    private lateinit var holder: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var statusTv: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var titleTv: TextView
    private lateinit var aspectBtn: Button

    private var player: ExoPlayer? = null
    private val ui = Handler(Looper.getMainLooper())

    private var isTv = false
    private var lite = false          // weak / low-RAM device -> lighter settings
    private var density = 1f

    // preview rectangle (physical px) reported by the web page
    private var paneX = 0
    private var paneY = 0
    private var paneW = 0
    private var paneH = 0
    private var paneSet = false

    private var fullscreen = false
    private var hasStream = false
    private var curUrl: String? = null
    private var curTitle = ""
    private var curLive = true
    private var resumePos = 0L
    private var retry = 0
    private var hlsTried = false
    private var gen = 0
    private var aspectIdx = 0

    private val hideTopRunnable = Runnable { if (curLive || !playerView.isControllerFullyVisible) topBar.visibility = View.GONE }

    // ------------------------------------------------------------------ lifecycle

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE } catch (_: Throwable) {}
        try { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) } catch (_: Throwable) {}

        density = resources.displayMetrics.density
        isTv = detectTv()
        lite = detectLite()

        val container = FrameLayout(this)
        container.setBackgroundColor(Color.parseColor("#070d1a"))

        try {
            val wv = WebView(this)
            wv.setBackgroundColor(Color.parseColor("#070d1a"))
            wv.isFocusable = true
            wv.isFocusableInTouchMode = true
            wv.overScrollMode = View.OVER_SCROLL_NEVER
            wv.isVerticalScrollBarEnabled = false
            wv.isHorizontalScrollBarEnabled = false

            val s = wv.settings
            s.javaScriptEnabled = true
            s.domStorageEnabled = true
            s.mediaPlaybackRequiresUserGesture = false
            s.allowFileAccess = true
            s.allowContentAccess = true
            try {
                @Suppress("DEPRECATION")
                s.allowUniversalAccessFromFileURLs = true
                @Suppress("DEPRECATION")
                s.allowFileAccessFromFileURLs = true
            } catch (_: Throwable) {}
            s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            s.useWideViewPort = true
            s.loadWithOverviewMode = true
            s.setSupportZoom(false)
            s.cacheMode = WebSettings.LOAD_DEFAULT
            s.userAgentString = "NEXTPLAY-Player/2.1 (Android; Android TV) AppleWebKit/537.36 Chrome/126.0.0.0"

            wv.addJavascriptInterface(NativeBridge(), "NextPlayNative")
            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
            }
            wv.webChromeClient = WebChromeClient()

            webView = wv
            container.addView(wv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

            buildPlayerLayer(container)
            setContentView(container)
            safeHideSystemUI()
            wv.loadUrl("file:///android_asset/www/index.html")
            wv.requestFocus()
        } catch (err: Throwable) {
            val tv = TextView(this)
            tv.setTextColor(Color.WHITE)
            tv.setPadding(40, 80, 40, 40)
            tv.text = "NEXT PLAY Player Error: " + (err.message ?: err.toString())
            container.addView(tv)
            setContentView(container)
        }
    }

    override fun onStart() {
        super.onStart()
        // came back from background: restart the stream that was playing
        val u = curUrl
        if (hasStream && u != null && player == null) startStream(u, curTitle, curLive, resumePos)
    }

    override fun onStop() {
        super.onStop()
        // release the hardware decoder while in background (frees RAM + codec for other apps)
        val p = player
        if (p != null) {
            resumePos = if (!curLive) p.currentPosition else 0L
            playerView.player = null
            p.release()
            player = null
        }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        try { playerView.player = null } catch (_: Throwable) {}
        try { player?.release() } catch (_: Throwable) {}
        player = null
        try { webView?.destroy() } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) safeHideSystemUI()
    }

    // ------------------------------------------------------------------ device profile

    private fun detectTv(): Boolean {
        return try {
            val um = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
            um.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
                !packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
        } catch (_: Throwable) { false }
    }

    private fun detectLite(): Boolean {
        return try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val cores = Runtime.getRuntime().availableProcessors()
            am.isLowRamDevice || am.memoryClass <= 128 || (cores <= 4 && Build.VERSION.SDK_INT < 28) || Build.VERSION.SDK_INT < 23
        } catch (_: Throwable) { true }
    }

    // ------------------------------------------------------------------ native player layer

    private fun buildPlayerLayer(container: FrameLayout) {
        holder = FrameLayout(this)
        holder.setBackgroundColor(Color.BLACK)
        holder.visibility = View.GONE
        holder.isFocusable = false
        holder.isClickable = true
        holder.setOnClickListener {
            if (fullscreen) toggleTopBar() else js("window.__npPaneTap&&window.__npPaneTap()")
        }

        playerView = PlayerView(this)
        playerView.useController = false
        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
        playerView.controllerShowTimeoutMs = 3500
        playerView.isFocusable = false
        playerView.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        playerView.setBackgroundColor(Color.BLACK)
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            if (fullscreen && !curLive) {
                if (vis == View.VISIBLE) { ui.removeCallbacks(hideTopRunnable); topBar.visibility = View.VISIBLE }
                else topBar.visibility = View.GONE
            }
        })
        holder.addView(playerView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        statusTv = TextView(this)
        statusTv.setTextColor(Color.WHITE)
        statusTv.setBackgroundColor(Color.parseColor("#B3000000"))
        statusTv.setPadding(24, 12, 24, 12)
        statusTv.textSize = 13f
        statusTv.gravity = Gravity.CENTER
        statusTv.visibility = View.GONE
        holder.addView(statusTv, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(24, 14, 24, 14)
        topBar.setBackgroundColor(Color.parseColor("#99030712"))
        topBar.visibility = View.GONE

        val back = Button(this)
        back.text = "← Back"
        back.isFocusable = false
        back.setTextColor(Color.parseColor("#040712"))
        back.setBackgroundColor(Color.parseColor("#FDE047"))
        back.setOnClickListener { setFullscreen(false, true) }
        topBar.addView(back)

        titleTv = TextView(this)
        titleTv.setTextColor(Color.WHITE)
        titleTv.textSize = 16f
        titleTv.setPadding(24, 0, 24, 0)
        topBar.addView(titleTv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        aspectBtn = Button(this)
        aspectBtn.text = "⛶ Fit"
        aspectBtn.isFocusable = false
        aspectBtn.setTextColor(Color.parseColor("#FDE047"))
        aspectBtn.setBackgroundColor(Color.parseColor("#CC0F172A"))
        aspectBtn.setOnClickListener { cycleAspect() }
        topBar.addView(aspectBtn)

        holder.addView(topBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        container.addView(holder, FrameLayout.LayoutParams(1, 1))
    }

    private fun applyLayout() {
        val lp = if (fullscreen) {
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        } else {
            FrameLayout.LayoutParams(max(paneW, 1), max(paneH, 1)).also {
                it.leftMargin = paneX
                it.topMargin = paneY
            }
        }
        holder.layoutParams = lp
        holder.visibility = if (hasStream && (fullscreen || paneSet)) View.VISIBLE else View.GONE
    }

    private fun buildItem(url: String, live: Boolean, forceHls: Boolean): MediaItem {
        val b = MediaItem.Builder().setUri(url)
        if (forceHls || url.contains(".m3u8", ignoreCase = true)) b.setMimeType(MimeTypes.APPLICATION_M3U8)
        if (live) {
            // no speed-up / slow-down "catch up" (it causes stutter on weak CPUs)
            b.setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setMinPlaybackSpeed(1f)
                    .setMaxPlaybackSpeed(1f)
                    .setTargetOffsetMs(if (lite) 8000L else 5000L)
                    .build()
            )
        }
        return b.build()
    }

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("VLC/3.0.20 LibVLC/3.0.20")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(15000)

        val mediaSourceFactory = DefaultMediaSourceFactory(http)
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(6))

        // Fast start (about half a second of video) + bigger safety buffer on weak devices.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                if (lite) 5000 else 3000,    // min buffer
                if (lite) 20000 else 40000,  // max buffer
                if (lite) 800 else 500,      // start playback after
                if (lite) 2500 else 1500     // resume after a stall
            )
            .apply { if (lite) setTargetBufferBytes(12 * 1024 * 1024) }
            .build()

        val renderers = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)

        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setHandleAudioBecomingNoisy(true)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(), true
            )
            .build()

        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    retry = 0
                    statusTv.visibility = View.GONE
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })

        playerView.player = p
        player = p
        return p
    }

    /** Video size limits: small in the preview, bigger in fullscreen. Only matters for multi-quality (HLS) streams. */
    private fun applyQuality() {
        val p = player ?: return
        val w: Int
        val h: Int
        val br: Int
        if (!fullscreen) {
            if (lite) { w = 640; h = 360; br = 1_200_000 } else { w = 960; h = 540; br = 2_500_000 }
        } else {
            if (lite) { w = 1280; h = 720; br = 4_000_000 } else { w = 1920; h = 1080; br = Int.MAX_VALUE }
        }
        try {
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setMaxVideoSize(w, h)
                .setMaxVideoBitrate(br)
                .build()
        } catch (_: Throwable) {}
    }

    private fun startStream(url: String, title: String, live: Boolean, startPos: Long = 0L) {
        curUrl = url
        curTitle = title
        curLive = live
        retry = 0
        hlsTried = false
        gen++
        hasStream = true
        titleTv.text = title
        statusTv.visibility = View.GONE
        try {
            val p = ensurePlayer()
            applyQuality()
            p.setMediaItem(buildItem(url, live, false), if (!live && startPos > 0) startPos else C.TIME_UNSET)
            p.prepare()
            p.playWhenReady = true
            playerView.useController = fullscreen && !live
        } catch (e: Throwable) {
            showStatus("Player error")
        }
        applyLayout()
    }

    private fun restartCurrent() {
        val p = player ?: return
        val u = curUrl ?: return
        p.setMediaItem(buildItem(u, curLive, hlsTried), true)
        p.prepare()
        p.playWhenReady = true
    }

    private fun handleError(error: PlaybackException) {
        val p = player ?: return
        val code = error.errorCode

        if (code == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            p.seekToDefaultPosition()
            p.prepare()
            return
        }
        // URL without ".m3u8" that is really an HLS playlist
        if (error.cause is UnrecognizedInputFormatException && !hlsTried && curUrl != null) {
            hlsTried = true
            restartCurrent()
            return
        }
        val decoderProblem = code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
            code == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ||
            code == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED

        if (decoderProblem) {
            if (!curLive) {
                // movie/episode too heavy for this device -> web layer asks the server for a light 720p version
                js("window.__npPlayFailed&&window.__npPlayFailed()")
            } else {
                showStatus("This channel's video format is not supported on this device")
            }
            return
        }
        if (retry < 6) {
            retry++
            showStatus("Reconnecting…")
            val g = gen
            ui.postDelayed({ if (g == gen && player != null) restartCurrent() }, 1200L * retry)
        } else {
            showStatus("Channel unavailable right now")
        }
    }

    private fun showStatus(msg: String) {
        statusTv.text = msg
        statusTv.visibility = View.VISIBLE
    }

    private fun stopAndHide() {
        gen++
        ui.removeCallbacks(hideTopRunnable)
        hasStream = false
        curUrl = null
        fullscreen = false
        statusTv.visibility = View.GONE
        topBar.visibility = View.GONE
        playerView.useController = false
        try { player?.stop(); player?.clearMediaItems() } catch (_: Throwable) {}
        applyLayout()
        webView?.requestFocus()
    }

    private fun setFullscreen(on: Boolean, fromNative: Boolean) {
        if (fullscreen == on) return
        fullscreen = on
        if (on) {
            playerView.useController = !curLive
            showTopBar()
            safeHideSystemUI()
        } else {
            playerView.useController = false
            ui.removeCallbacks(hideTopRunnable)
            topBar.visibility = View.GONE
            playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            aspectIdx = 0
            aspectBtn.text = "⛶ Fit"
            if (!curLive) {
                // movies/episodes have no preview pane: stop and hide
                gen++
                hasStream = false
                curUrl = null
                try { player?.stop(); player?.clearMediaItems() } catch (_: Throwable) {}
            }
            webView?.requestFocus()
        }
        applyLayout()
        applyQuality()
        if (!on && fromNative) js("window.__npFsExited&&window.__npFsExited()")
    }

    private fun showTopBar() {
        topBar.visibility = View.VISIBLE
        ui.removeCallbacks(hideTopRunnable)
        ui.postDelayed(hideTopRunnable, 3500)
    }

    private fun toggleTopBar() {
        if (curLive) {
            if (topBar.visibility == View.VISIBLE) { ui.removeCallbacks(hideTopRunnable); topBar.visibility = View.GONE }
            else showTopBar()
        }
    }

    private fun cycleAspect() {
        aspectIdx = (aspectIdx + 1) % 3
        val modes = intArrayOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        )
        val labels = arrayOf("⛶ Fit", "⛶ Zoom", "⛶ Stretch")
        playerView.resizeMode = modes[aspectIdx]
        aspectBtn.text = labels[aspectIdx]
    }

    // ------------------------------------------------------------------ JS bridge

    private fun js(code: String) {
        runOnUiThread { try { webView?.evaluateJavascript(code, null) } catch (_: Throwable) {} }
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun isTv(): Boolean = this@MainActivity.isTv

        /** Position of the preview box in CSS pixels. */
        @JavascriptInterface
        fun setPane(x: Double, y: Double, w: Double, h: Double) {
            runOnUiThread {
                val nx = (x * density).roundToInt()
                val ny = (y * density).roundToInt()
                val nw = (w * density).roundToInt()
                val nh = (h * density).roundToInt()
                val changed = nx != paneX || ny != paneY || nw != paneW || nh != paneH || !paneSet
                paneX = nx; paneY = ny; paneW = nw; paneH = nh
                paneSet = nw > 0 && nh > 0
                if (changed && !fullscreen) applyLayout()
            }
        }

        @JavascriptInterface
        fun play(url: String, title: String, isLive: Boolean) {
            runOnUiThread { startStream(url, title, isLive) }
        }

        @JavascriptInterface
        fun setFullscreen(on: Boolean) {
            runOnUiThread { this@MainActivity.setFullscreen(on, false) }
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread { stopAndHide() }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finishAffinity() }
        }
    }

    // ------------------------------------------------------------------ remote control

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode

        if (code == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (fullscreen) setFullscreen(false, true)
                else if (webView != null) js("window.__npAndroidBack&&window.__npAndroidBack()")
                else finish()
            }
            return true
        }
        if (fullscreen) return handleFullscreenKey(event)
        return super.dispatchKeyEvent(event)
    }

    private fun handleFullscreenKey(e: KeyEvent): Boolean {
        val code = e.keyCode
        val handled = when (code) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_CHANNEL_DOWN,
            KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_PAGE_DOWN,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_MEDIA_REWIND,
            KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS,
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_RED -> true
            else -> false
        }
        if (!handled) return super.dispatchKeyEvent(e)
        if (e.action != KeyEvent.ACTION_DOWN) return true

        val p = player
        when (code) {
            // ---- channel zapping (live) ----
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_UP ->
                if (curLive) { js("window.__npZap&&window.__npZap(-1)"); showTopBar() } else showVodController()
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_DOWN ->
                if (curLive) { js("window.__npZap&&window.__npZap(1)"); showTopBar() } else showVodController()

            // ---- seeking (movies / episodes) ----
            KeyEvent.KEYCODE_DPAD_LEFT ->
                if (curLive) showTopBar() else seekBy(if (e.repeatCount > 5) -30000L else -10000L)
            KeyEvent.KEYCODE_DPAD_RIGHT ->
                if (curLive) showTopBar() else seekBy(if (e.repeatCount > 5) 30000L else 10000L)
            KeyEvent.KEYCODE_MEDIA_REWIND -> if (!curLive) seekBy(-30000L)
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> if (!curLive) seekBy(30000L)

            // ---- OK / play / pause ----
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER ->
                if (curLive) showTopBar() else { togglePlay(p); showVodController() }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(p); if (!curLive) showVodController() }
            KeyEvent.KEYCODE_MEDIA_PLAY -> p?.play()
            KeyEvent.KEYCODE_MEDIA_PAUSE -> p?.pause()

            // ---- picture mode ----
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_RED -> { cycleAspect(); showTopBar() }
            KeyEvent.KEYCODE_INFO -> showTopBar()
        }
        return true
    }

    private fun togglePlay(p: ExoPlayer?) {
        if (p == null) return
        if (p.isPlaying) p.pause() else p.play()
    }

    private fun showVodController() {
        if (!curLive) playerView.showController()
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val dur = p.duration
        var t = (p.currentPosition + deltaMs).coerceAtLeast(0L)
        if (dur != C.TIME_UNSET) t = t.coerceAtMost(dur)
        p.seekTo(t)
        showVodController()
    }

    // ------------------------------------------------------------------ system UI

    private fun safeHideSystemUI() {
        try {
            window.decorView.post {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        window.setDecorFitsSystemWindows(false)
                        window.insetsController?.let { c ->
                            c.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                            c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        window.decorView.systemUiVisibility = (
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_FULLSCREEN
                            )
                    }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }
}
